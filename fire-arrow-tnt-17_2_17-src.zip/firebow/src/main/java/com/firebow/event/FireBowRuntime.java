package com.firebow.event;

import com.firebow.util.AsyncRunner;
import com.firebow.util.InteractionUtil;
import com.firebow.util.InventoryUtil;
import com.firebow.util.PingUtil;
import com.firebow.util.RotationUtil;
import com.firebow.util.SearchResult;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v14 — silent rotation, CONFIRM tách khỏi job.
 *
 *   job (SEND → CART): đặt rail rồi cart, mỗi bước 1 tick. Xong cart là job trả về null ngay,
 *                      nên mũi tên tiếp theo không phải chờ.
 *   confirms         : sau khi đặt cart, chờ ping/50+2 tick kiểm tra cart spawn.
 *                      Không spawn → đưa vào retries, job sau sẽ đặt lại (tối đa MAX_PLACE_ATTEMPTS).
 *
 * Vòng đời mỗi tick:
 *   HEAD tickMovement        → beforeMovement(): arm nếu bước này sẵn sàng
 *   HEAD sendMovementPackets → RotationUtil.applyToPacket()
 *   END_CLIENT_TICK          → tickConfirms(), stepJob() (interact), rồi RotationUtil.end()
 *
 * Tốc độ tối thiểu: arrow spawn (ping sau khi thả cung) + 2 tick (rail, cart).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_WAIT           = 20;   // tick chờ điều kiện trước mỗi bước
    private static final int  MAX_JOB_TICKS      = 120;
    private static final int  MAX_CONFIRM_TICKS  = 30;

    private enum Phase { SEND, CART }

    private static final class RailJob {
        final BlockPos pos;
        int    attempts = 0;       // số lần đã interact đặt rail (kế thừa khi retry)
        Phase phase      = Phase.SEND;
        int   ticks      = 0;
        int   totalTicks = 0;

        RailJob(BlockPos pos, int attempts) {
            this.pos      = pos;
            this.attempts = attempts;
        }
    }

    private static final class Confirm {
        final BlockPos pos;
        final int attempts;
        int ticksLeft;

        Confirm(BlockPos pos, int attempts, int ticksLeft) {
            this.pos       = pos;
            this.attempts  = attempts;
            this.ticksLeft = ticksLeft;
        }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private final List<Confirm>  confirms = new ArrayList<>();
    private final List<RailJob>  retries  = new ArrayList<>();
    private volatile boolean enabled = true;
    private RailJob job = null;  // chỉ đọc/ghi trên main thread, job là bước đang đặt

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── HEAD tickMovement: arm góc nếu bước này sẵn sàng ───────────────────

    public void beforeMovement() {
        if (!enabled || job == null || RotationUtil.isActive()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;

        if (!stepReady(mc, p, job)) return;
        Vec3d hit = armTarget(mc, job);
        if (hit == null) return;

        RotationUtil.arm(p, hit);
    }

    private static boolean stepReady(MinecraftClient mc, ClientPlayerEntity p, RailJob j) {
        return switch (j.phase) {
            case SEND -> !isRail(mc, j.pos)
                    && !InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()
                    && InteractionUtil.railReady(mc, p, j.pos);
            case CART -> isRail(mc, j.pos)
                    && !InventoryUtil.findItem(Items.TNT_MINECART).isMissing()
                    && InteractionUtil.cartReady(mc, p, j.pos);
        };
    }

    private static Vec3d armTarget(MinecraftClient mc, RailJob j) {
        return switch (j.phase) {
            case SEND -> isRail(mc, j.pos) ? null : RotationUtil.calcHitVec(j.pos.down(), Direction.UP);
            case CART -> isRail(mc, j.pos) ? RotationUtil.calcHitVec(j.pos, Direction.UP) : null;
        };
    }

    // ─── Arrow tick: nhận yêu cầu đặt rail ──────────────────────────────────

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);

        job = new RailJob(railPos, 0);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                confirms.clear();
                retries.clear();
                RotationUtil.end(null);
                return;
            }

            tickConfirms(mc);

            if (!enabled) {
                if (job != null) abort();
                return;
            }

            if (job == null && !retries.isEmpty()) job = retries.remove(0);
            if (job != null) stepJob(mc);
        } finally {
            RotationUtil.end(mc.player);
        }
    }

    private void stepJob(MinecraftClient mc) {
        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(); return; }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                if (railThere) { enter(j, Phase.CART); return; }
                if (!RotationUtil.isActive()) {
                    if (j.ticks > MAX_WAIT) abort();
                    return;
                }

                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> { j.attempts++; enter(j, Phase.CART); }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(); }
                    case INVALID   -> abort();
                }
            }

            case CART -> {
                // rail client-side mất ngay = server đã từ chối → đặt lại rail
                if (!railThere) {
                    if (j.attempts >= MAX_PLACE_ATTEMPTS) abort();
                    else enter(j, Phase.SEND);
                    return;
                }
                if (!RotationUtil.isActive()) {
                    if (j.ticks > MAX_WAIT) abort();
                    return;
                }

                // đã có cart trên rail (spawn chậm, hoặc shot trước) → không đặt thêm
                if (cartPresent(mc, j.pos)) { job = null; return; }

                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { abort(); return; }

                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    confirms.add(new Confirm(j.pos, j.attempts, verifyWindow(mc)));
                    job = null;   // job trả về ngay, không chờ confirm
                } else if (j.ticks > MAX_WAIT) {
                    abort();
                }
            }
        }
    }

    /**
     * Hết thời gian chờ mà chưa thấy cart:
     *  - rail vẫn còn: không retry (có thể cart spawn chậm). tránh đặt trùng.
     *  - rail đã mất: server đã từ chối cả rail, retry từ đầu.
     */
    private void tickConfirms(MinecraftClient mc) {
        for (int i = confirms.size() - 1; i >= 0; i--) {
            Confirm c = confirms.get(i);
            c.ticksLeft--;
            if (c.ticksLeft > 0) continue;

            confirms.remove(i);
            if (cartPresent(mc, c.pos)) continue;
            if (!isRail(mc, c.pos) && c.attempts < MAX_PLACE_ATTEMPTS) {
                retries.add(new RailJob(c.pos, c.attempts));
            }
        }
    }

    private static void enter(RailJob j, Phase phase) {
        j.phase = phase;
        j.ticks = 0;
    }

    private static int verifyWindow(MinecraftClient mc) {
        long ping = PingUtil.getPingMs(mc);
        return (int) Math.min(MAX_CONFIRM_TICKS, ping / 50L + 4L);
    }

    private void abort() {
        job = null;
    }

    /** Có TNT minecart nằm đúng trên block rail này không (cart trên rail có blockPos = rail). */
    private static boolean cartPresent(MinecraftClient mc, BlockPos pos) {
        Box box = new Box(pos.getX(), pos.getY(), pos.getZ(),
                          pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1);
        return !mc.world.getEntitiesByClass(TntMinecartEntity.class, box,
                e -> e.getBlockPos().equals(pos)).isEmpty();
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }
}
