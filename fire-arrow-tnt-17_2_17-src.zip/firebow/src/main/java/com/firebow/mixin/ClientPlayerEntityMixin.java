package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.RotationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    /** HEAD tickMovement: arm góc trước khi input được đọc và velocity được tính. */
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void firebow$beforeMovement(CallbackInfo ci) {
        FireBowRuntime.get().beforeMovement();
    }

    /** HEAD sendMovementPackets: đưa silent yaw/pitch lên player để packet mang nó. */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$applyPacket(CallbackInfo ci) {
        RotationUtil.applyToPacket((ClientPlayerEntity) (Object) this);
    }
}
