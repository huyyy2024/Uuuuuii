package com.firebow.mixin;

import com.firebow.util.RotationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Khi silent rotation đang active, velocity của player được tính theo silentYaw,
 * khớp với yaw trong movement packet.
 */
@Environment(EnvType.CLIENT)
@Mixin(Entity.class)
public abstract class EntityMixin {

    @Inject(method = "updateVelocity", at = @At("HEAD"), cancellable = true)
    private void firebow$silentVelocity(float speed, Vec3d input, CallbackInfo ci) {
        if (!RotationUtil.isActive()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        Entity self = (Entity) (Object) this;
        if (mc.player == null || self != mc.player) return;

        Vec3d v = RotationUtil.movementInputToVelocity(input, speed, RotationUtil.silentYaw());
        self.setVelocity(self.getVelocity().add(v));
        ci.cancel();
    }
}
